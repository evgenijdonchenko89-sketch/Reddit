#!/data/data/com.termux/files/usr/bin/bash
pkg update -y && pkg upgrade -y
pkg install python -y
pip install --upgrade pip wheel setuptools
pip install -r requirements.txt
echo "✅ Готово! Теперь поиск только по постам с текстом (self:true)"
echo "Запуск: python main.py"
