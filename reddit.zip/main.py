from src.scraper import search_reddit_max
from src.utils import save_posts

def interactive():
    print("\n🚀 УЛУЧШЕННЫЙ Reddit Scraper 2026")
    print("   Только посты с текстом (self:true) + максимум страниц")
    print("")

    query = input("🔍 Ключевые слова: ").strip()
    if not query:
        print("Нужен запрос!")
        return

    limit_input = input("📊 Макс. постов (0 = без лимита, выжать всё возможное): ").strip()
    max_posts = int(limit_input) if limit_input.isdigit() else 0

    sub = input("📌 Субреддит (all = весь Reddit): ").strip().lower() or "all"

    print("\nСортировка:")
    print("  1 = new     2 = hot     3 = top     4 = relevance")
    ch = input("Выбор (1-4) [1]: ").strip() or "1"
    sort_map = {"1":"new", "2":"hot", "3":"top", "4":"relevance"}
    sort = sort_map.get(ch, "new")

    only_text = input("📝 Только посты с текстом? (y/n) [y по умолчанию]: ").strip().lower() != "n"

    print(f"\n🔥 Старт: \"{query}\" | max: {'∞' if max_posts == 0 else max_posts} | sub: {sub} | sort: {sort} | только текст: {'Да' if only_text else 'Нет'}")
    if input("Продолжить? (y/n): ").strip().lower() != 'y':
        print("Отменено.")
        return

    posts = search_reddit_max(query, max_posts, sub, sort, only_text)
    if posts:
        save_posts(posts, query)
    else:
        print("❌ Ничего не найдено (или бан IP). Включи VPN и попробуй снова.")

if __name__ == "__main__":
    interactive()
