import requests
from urllib.parse import quote_plus
from tenacity import retry, stop_after_attempt, wait_exponential
from .config import get_headers, random_sleep
from datetime import datetime

@retry(stop=stop_after_attempt(10), wait=wait_exponential(min=8, max=90))
def fetch_json(url):
    headers = get_headers()
    resp = requests.get(url, headers=headers, timeout=20)
    resp.raise_for_status()
    return resp.json()


def search_reddit_max(query, max_posts=0, subreddit="all", sort="new", only_text=True):
    """
    only_text=True → добавляет &self=true (официальный фильтр Reddit 2026)
    Берёт ТОЛЬКО посты с текстом (selftext не пустой)
    """
    all_posts = []
    after = None
    page = 0
    skipped = 0

    while True:
        page += 1
        params = f"q={quote_plus(query)}&sort={sort}&limit=100"
        if after:
            params += f"&after={after}"
        if only_text:
            params += "&self=true"          # ← главный апгрейд! Только текстовые посты
        params += "&count=100"

        if subreddit != "all":
            url = f"https://old.reddit.com/r/{subreddit}/search.json?{params}&restrict_sr=on"
        else:
            url = f"https://old.reddit.com/search.json?{params}"

        print(f"📄 Страница {page} | найдено текстовых: {len(all_posts)} | after={after[:8] if after else 'нет'}")

        try:
            data = fetch_json(url)
            children = data["data"]["children"]

            if not children:
                print("Больше нет постов")
                break

            for child in children:
                post = child["data"]
                selftext = post.get("selftext", "").strip()

                # Дополнительная проверка (на случай если фильтр не сработал идеально)
                if only_text and not selftext:
                    skipped += 1
                    continue

                created = datetime.utcfromtimestamp(post.get("created_utc", 0)).strftime("%Y-%m-%d %H:%M UTC")

                all_posts.append({
                    "title": post.get("title", "[без заголовка]"),
                    "selftext": selftext,
                    "subreddit": post.get("subreddit", "?"),
                    "score": post.get("score", "?"),
                    "ups": post.get("ups", "?"),
                    "date": created,
                    "permalink": "https://old.reddit.com" + post.get("permalink", ""),
                    "url": post.get("url", ""),
                    "id": post.get("id", "")
                })

            after = data["data"]["after"]
            if not after:
                print("Конец результатов (after = None)")
                break

            random_sleep()

            if max_posts > 0 and len(all_posts) >= max_posts:
                print(f"Достигнут лимит {max_posts} текстовых постов")
                break

        except Exception as e:
            print(f"Ошибка страницы {page}: {e}")
            break

    print(f"✅ Итого текстовых постов: {len(all_posts)} (пропущено без текста: {skipped})")
    return all_posts
