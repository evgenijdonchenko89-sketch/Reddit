from datetime import datetime
from pathlib import Path
import re

def save_posts(posts, query):
    base_dir = Path("output/results/posts")
    base_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_query = re.sub(r'[^a-zA-Z0-9_-]', '_', query)[:30]

    summary_file = Path("output/results") / f"summary_{ts}_{safe_query}.txt"

    with open(summary_file, "w", encoding="utf-8") as sum_f:
        sum_f.write(f"Поиск: \"{query}\" (только текстовые посты)\n")
        sum_f.write(f"Найдено: {len(posts)} постов с текстом\n\n")

        for i, p in enumerate(posts, 1):
            safe_title = re.sub(r'[^a-zA-Z0-9_-]', '_', p['title'])[:50]
            fn = f"post_{ts}_{safe_query}_{i:04d}_{safe_title}.txt"
            post_file = base_dir / fn

            with open(post_file, "w", encoding="utf-8") as f:
                f.write(f"Title: {p['title']}\n")
                f.write(f"r/{p['subreddit']} | Score: {p['score']} (ups: {p['ups']})\n")
                f.write(f"Date: {p['date']}\n")
                f.write(f"Permalink: {p['permalink']}\n")
                f.write(f"URL: {p['url']}\n\n")
                f.write("═" * 70 + "\n")
                f.write("ТЕКСТ ПОСТА (полный):\n\n")
                f.write(p['selftext'] + "\n")
                f.write("\n" + "═" * 70 + "\n")

            sum_f.write(f"{i:04d}. ↑{p['score']} {p['title'][:75]}...\n")
            sum_f.write(f"     r/{p['subreddit']} → {fn}\n\n")

    print(f"💾 Сохранено {len(posts)} файлов (только с текстом!)")
    print(f"📋 Summary: {summary_file}")
