from fake_useragent import UserAgent
import random
import time

ua = UserAgent()

HEADERS = {
    "Accept": "application/json",
    "Accept-Language": "en-US,en;q=0.5",
    "Referer": "https://old.reddit.com/",
}

MIN_DELAY = 5.5
MAX_DELAY = 12.0

def get_headers():
    return {**HEADERS, "User-Agent": ua.random}

def random_sleep():
    time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))
