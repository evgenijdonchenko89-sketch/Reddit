# Reddit Keyword Search (без API, 2026)

Парсер поиска по ключевым словам на old.reddit.com  
(работает без официального API, но Reddit банит IP очень быстро в 2026)

## Установка в Termux
./install.sh   (или вручную: pip install -r requirements.txt)

## Запуск
python main.py "python termux" 15
python main.py "android hacking" 30 --sub all

Результаты → в output/results/
